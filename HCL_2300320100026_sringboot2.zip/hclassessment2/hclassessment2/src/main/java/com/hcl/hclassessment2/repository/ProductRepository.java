package com.hcl.hclassessment2.repository;

import com.hcl.hclassessment2.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product,Long> {
}
