package com.hcl.hclassessment2.controller;

import com.hcl.hclassessment2.entity.Cart;
import com.hcl.hclassessment2.service.CartService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cart")
public class CartController {

    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    // 1. CREATE
    @PostMapping("/create")
    public ResponseEntity<Cart> createCart(@RequestBody Cart cart) {
        Cart createdCart = cartService.create(cart);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(createdCart);
    }

    // 2. READ (Get All)
    @GetMapping("/all")
    public ResponseEntity<List<Cart>> getAllCarts() {
        List<Cart> carts = cartService.getAllCarts();
        return ResponseEntity.ok(carts);
    }

    // 3. READ (Get By ID)
    @GetMapping("/get/{id}")
    public ResponseEntity<Cart> getCartById(@PathVariable("id") Long cartId) {
        Cart cart = cartService.readbyidservice(cartId);
        if (cart == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(cart);
    }

    // 4. UPDATE
    @PutMapping("/update/{id}")
    public ResponseEntity<Cart> updateCart(@PathVariable("id") Long cartId, @RequestBody Cart cartDetails) {
        Cart updatedCart = cartService.updateCart(cartId, cartDetails);
        if (updatedCart == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(updatedCart);
    }

    // 5. DELETE
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteCart(@PathVariable("id") Long cartId) {
        boolean deleted = cartService.deleteCart(cartId);
        if (!deleted) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }
}
