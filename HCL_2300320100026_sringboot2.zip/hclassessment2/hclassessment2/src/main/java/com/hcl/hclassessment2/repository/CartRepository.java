package com.hcl.hclassessment2.repository;

import com.hcl.hclassessment2.entity.Cart;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CartRepository extends JpaRepository<Cart,Long> {

}
