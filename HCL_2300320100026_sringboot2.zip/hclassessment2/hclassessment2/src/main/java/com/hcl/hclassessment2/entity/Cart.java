package com.hcl.hclassessment2.entity;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
//@GeneratedValue(strategy = GenerationType.IDENTITY)
//@OneToMany(mappedBy="order",cascade= CascadeType.ALL)
public class Cart {

    @Id
    private Long cartId;

    private Customer customer;
    private LocalDate createdDate;

    public Long getCartId() {
        return cartId;
    }

    public void setCartId(Long cartId) {
        this.cartId = cartId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public LocalDate getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDate createdDate) {
        this.createdDate = createdDate;
    }
}


