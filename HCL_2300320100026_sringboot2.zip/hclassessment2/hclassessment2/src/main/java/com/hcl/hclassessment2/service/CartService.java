package com.hcl.hclassessment2.service;

import com.hcl.hclassessment2.entity.Cart;
import com.hcl.hclassessment2.repository.CartRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class CartService {

    private final CartRepository cartRepository;

    public CartService(CartRepository cartRepository) {
        this.cartRepository = cartRepository;
    }

    // 1. CREATE
    public Cart create(Cart cart) {
        return cartRepository.save(cart);
    }

    // 2. READ (Single record by ID)
    public Cart readbyidservice(Long cartId) {
        return cartRepository.findById(cartId).orElse(null);
    }

    // 2b. READ (All records - Optional but highly useful)
    public List<Cart> getAllCarts() {
        return cartRepository.findAll();
    }

    // 3. UPDATE
    public Cart updateCart(Long cartId, Cart updatedCart) {
        return cartRepository.findById(cartId)
                .map(existingCart -> {
                    return cartRepository.save(existingCart);
                })
                .orElse(null);
    }

    // 4. DELETE
    public boolean deleteCart(Long cartId) {
        if (cartRepository.existsById(cartId)) {
            cartRepository.deleteById(cartId);
            return true;
        }
        return false;
    }
}
