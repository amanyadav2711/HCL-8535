package com.hcl.hclassessment2.collector;


public class CustomerController {
}
