package com.hcl.hclassessment2.repository;

public interface CartItemRepository {
}
