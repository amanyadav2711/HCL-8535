package com.hcl.hclassessment2.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class CartItemController {
}
