package com.hcl.hclassessment2.service;

public class CustomerService {
}
